import React, { useState } from "react";
import { toggleMode } from "../api/openai";

export default function AudioRecorder({ className = "" }) {
  const [isRecording, setIsRecording] = useState(false);

  const handleToggle = async () => {
    try {
      await toggleMode();
      setIsRecording(!isRecording);
    } catch (error) {
      console.error("Error toggling recording mode:", error);
    }
  };

  return (
    <div className={`flex items-center justify-center w-full ${className}`}>
      <button
        onClick={handleToggle}
        className={`px-4 py-2 rounded-full transition ${
          isRecording 
            ? "bg-red-500 hover:bg-red-600 animate-pulse" 
            : "bg-green-500 hover:bg-green-600"
        } text-white`}
      >
        {isRecording ? "⏹ Stop Recording" : "🎤 Start Recording"}
      </button>
    </div>
  );
}