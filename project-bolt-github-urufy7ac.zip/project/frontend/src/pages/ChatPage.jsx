import React, { useState, useEffect, useRef } from "react";
import { getTranscript, sendChatMessage } from "../api/openai";
import ChatInterface from "../components/ChatInterface";
import AudioRecorder from "../components/AudioRecorder";
import "./ChatPage.css";

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [isThinking, setIsThinking] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const pollingInterval = useRef(null);

  // Handle text input submission
  const handleSubmit = async (text) => {
    if (!text.trim()) return;

    // Add user message
    const userMessage = { text, isUser: true };
    setMessages(prev => [...prev, userMessage]);
    setIsThinking(true);

    try {
      // Get AI response
      const response = await sendChatMessage(text);
      const aiMessage = { text: response, isUser: false };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error getting AI response:", error);
      const errorMessage = { text: "Sorry, I encountered an error.", isUser: false };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsThinking(false);
    }
  };

  // Poll for new transcripts in voice mode
  useEffect(() => {
    if (isVoiceMode) {
      let lastTranscript = "";
      pollingInterval.current = setInterval(async () => {
        const transcripts = await getTranscript();
        if (transcripts.length > 0 && transcripts[transcripts.length - 1] !== lastTranscript) {
          lastTranscript = transcripts[transcripts.length - 1];
          handleSubmit(lastTranscript);
        }
      }, 2000);
    }

    return () => {
      if (pollingInterval.current) {
        clearInterval(pollingInterval.current);
      }
    };
  }, [isVoiceMode]);

  return (
    <div className="flex flex-col h-[calc(100vh-6rem)] p-4 max-w-4xl mx-auto">
      <div className="flex-1 mb-4">
        <ChatInterface
          messages={messages}
          isThinking={isThinking}
        />
      </div>
      
      <div className="flex items-center gap-4">
        <button
          onClick={() => setIsVoiceMode(!isVoiceMode)}
          className="px-4 py-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition"
        >
          {isVoiceMode ? "Switch to Text" : "Switch to Voice"}
        </button>
        
        {isVoiceMode ? (
          <AudioRecorder onTranscription={() => {}} />
        ) : (
          <input
            type="text"
            placeholder="Type your message..."
            className="flex-1 p-2 border rounded-full"
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSubmit(e.target.value);
                e.target.value = '';
              }
            }}
          />
        )}
      </div>
    </div>
  );
}