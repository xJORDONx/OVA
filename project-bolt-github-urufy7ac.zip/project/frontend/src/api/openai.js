// API endpoints for different services
const API_ENDPOINTS = {
  STT_SERVICE: 'http://localhost:9575',
  TEXT_GEN_SERVICE: 'http://localhost:8989',
  TTS_SERVICE: 'http://localhost:8000'
};

export async function sendChatMessage(messages) {
  try {
    const response = await fetch(`${API_ENDPOINTS.TEXT_GEN_SERVICE}/respond`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ input: messages })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error('Error sending chat message:', error);
    return "Sorry, I encountered an error processing your request.";
  }
}

export async function getTranscript(mode = 'plain') {
  try {
    const response = await fetch(`${API_ENDPOINTS.STT_SERVICE}/transcript?mode=${mode}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching transcript:', error);
    return [];
  }
}

export async function toggleMode() {
  try {
    const response = await fetch(`${API_ENDPOINTS.TEXT_GEN_SERVICE}/toggle_mode`, {
      method: 'POST'
    });
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error toggling mode:', error);
    return { mode: 'text' };
  }
}